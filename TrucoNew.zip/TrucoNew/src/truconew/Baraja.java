
package truconew;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baraja {
    private List<Carta> cartas;
    private List<Carta> cartasMonton;
    private int indiceActual;

    public Baraja() {
        cartas = new ArrayList<>();
        cartasMonton = new ArrayList<>();
        inicializarBaraja();
        barajar();
    }

    private void inicializarBaraja() {
        String[] palos = {"espadas", "bastos", "oros", "copas"};
        for (String palo : palos) {
            for (int numero = 1; numero <= 12; numero++) {
                if (numero != 8 && numero != 9) {
                    cartas.add(new Carta(numero, palo));
                }
            }
        }
    }

    public void barajar() {
        Collections.shuffle(cartas);
        indiceActual = 0;
    }

    public Carta siguienteCarta() {
        if (indiceActual < cartas.size()) {
            Carta carta = cartas.get(indiceActual);
            cartasMonton.add(carta);
            indiceActual++;
            return carta;
        } else {
            System.out.println("No hay más cartas.");
            return null;
        }
    }

    public int cartasDisponibles() {
        return cartas.size() - indiceActual;
    }

    public List<Carta> darCartas(int numCartas) {
        if (numCartas > cartasDisponibles()) {
            System.out.println("No hay suficientes cartas disponibles.");
            return new ArrayList<>();
        } else {
            List<Carta> cartasSolicitadas = new ArrayList<>();
            for (int i = 0; i < numCartas; i++) {
                Carta carta = siguienteCarta();
                if (carta != null) {
                    cartasSolicitadas.add(carta);
                }
            }
            return cartasSolicitadas;
        }
    }

    public List<Carta> cartasMonton() {
        if (cartasMonton.isEmpty()) {
            System.out.println("No se han sacado cartas.");
            return new ArrayList<>();
        } else {
            return new ArrayList<>(cartasMonton);
        }
    }

    public void mostrarBaraja() {
        if (indiceActual >= cartas.size()) {
            System.out.println("No quedan cartas en la baraja.");
        } else {
            for (int i = indiceActual; i < cartas.size(); i++) {
                System.out.println(cartas.get(i));
            }
        }
    }
}
