
package truconew;

public class Carta {
    private int numero;
    private String palo;

    public Carta(int numero, String palo) {
        if (numero < 1 || numero > 12 || numero == 8 || numero == 9) {
            throw new IllegalArgumentException("Número de carta inválido. Debe ser entre 1 y 12, excluyendo 8 y 9.");
        }
        if (!palo.equals("espadas") && !palo.equals("bastos") && !palo.equals("oros") && !palo.equals("copas")) {
            throw new IllegalArgumentException("Palo de carta inválido.");
        }
        this.numero = numero;
        this.palo = palo;
    }

    @Override
    public String toString() {
        return numero + " de " + palo;
    }
}
