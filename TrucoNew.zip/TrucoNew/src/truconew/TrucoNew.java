
package truconew;

import java.util.List;


public class TrucoNew {

   public static void main(String[] args) {
        Baraja baraja = new Baraja();
        
        System.out.println("Cartas disponibles en la baraja: " + baraja.cartasDisponibles());
        
        System.out.println("Mostrando cartas restantes en la baraja:");
        baraja.mostrarBaraja();
        
        System.out.println("\nDando 5 cartas:");
        List<Carta> cartas = baraja.darCartas(5);
        for (Carta carta : cartas) {
            System.out.println(carta);
        }
        
        System.out.println("\nCartas monton:");
        for (Carta carta : baraja.cartasMonton()) {
            System.out.println(carta);
        }
        
        System.out.println("\nMostrando cartas restantes en la baraja:");
        baraja.mostrarBaraja();
    }
    
}
